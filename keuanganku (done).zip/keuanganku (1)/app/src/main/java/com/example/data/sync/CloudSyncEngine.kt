package com.example.data.sync

import com.example.data.dao.CloudSyncLogDao
import com.example.data.dao.TransactionDao
import com.example.data.model.CloudSyncLogEntity
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Success(val message: String, val syncedCount: Int) : SyncState()
    data class Error(val errorMessage: String) : SyncState()
}

class CloudSyncEngine(
    private val transactionDao: TransactionDao,
    private val cloudSyncLogDao: CloudSyncLogDao
) {

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _isAutoSyncEnabled = MutableStateFlow(true)
    val isAutoSyncEnabled: StateFlow<Boolean> = _isAutoSyncEnabled.asStateFlow()

    fun setAutoSyncEnabled(enabled: Boolean) {
        _isAutoSyncEnabled.value = enabled
    }

    suspend fun performSync(): SyncResult {
        if (_syncState.value is SyncState.Syncing) {
            return SyncResult(false, "Sync sedang berjalan...")
        }

        _syncState.value = SyncState.Syncing

        return try {
            val unsyncedList = transactionDao.getUnsyncedTransactions()
            val now = System.currentTimeMillis()

            // Simulate cloud server REST API latency (1.2s)
            delay(1200)

            if (unsyncedList.isEmpty()) {
                // All items are up to date
                cloudSyncLogDao.insertLog(
                    CloudSyncLogEntity(
                        timestamp = now,
                        status = "BERHASIL",
                        itemsSyncedCount = 0,
                        detailMessage = "Data lokal sudah terbaru. Semua transaksi tersinkron."
                    )
                )
                val msg = "Semua data transaksi sudah tersinkron dengan cloud."
                _syncState.value = SyncState.Success(msg, 0)
                SyncResult(true, msg, 0)
            } else {
                // Sync unsynced items
                val idsToSync = unsyncedList.map { it.id }
                transactionDao.markAsSynced(idsToSync, now)

                cloudSyncLogDao.insertLog(
                    CloudSyncLogEntity(
                        timestamp = now,
                        status = "BERHASIL",
                        itemsSyncedCount = unsyncedList.size,
                        detailMessage = "Berhasil menyinkronkan ${unsyncedList.size} data transaksi baru ke cloud database."
                    )
                )

                val msg = "Berhasil menyinkronkan ${unsyncedList.size} transaksi ke cloud."
                _syncState.value = SyncState.Success(msg, unsyncedList.size)
                SyncResult(true, msg, unsyncedList.size)
            }
        } catch (e: Exception) {
            val now = System.currentTimeMillis()
            val errorMsg = e.localizedMessage ?: "Gagal terhubung ke cloud server."
            cloudSyncLogDao.insertLog(
                CloudSyncLogEntity(
                    timestamp = now,
                    status = "GAGAL",
                    itemsSyncedCount = 0,
                    detailMessage = "Gagal sync: $errorMsg"
                )
            )
            _syncState.value = SyncState.Error(errorMsg)
            SyncResult(false, errorMsg, 0)
        }
    }

    fun exportTransactionsToJson(transactions: List<TransactionEntity>): String {
        val jsonArray = JSONArray()
        for (tx in transactions) {
            val obj = JSONObject().apply {
                put("id", tx.id)
                put("title", tx.title)
                put("amount", tx.amount)
                put("type", tx.type.name)
                put("category", tx.category)
                put("note", tx.note)
                put("timestamp", tx.timestamp)
                put("isSynced", true)
            }
            jsonArray.put(obj)
        }
        val wrapper = JSONObject().apply {
            put("app", "KeuanganKu")
            put("version", "1.0")
            put("exportedAt", System.currentTimeMillis())
            put("transactions", jsonArray)
        }
        return wrapper.toString(2)
    }

    fun resetSyncState() {
        _syncState.value = SyncState.Idle
    }
}

data class SyncResult(
    val isSuccess: Boolean,
    val message: String,
    val syncedCount: Int = 0
)
