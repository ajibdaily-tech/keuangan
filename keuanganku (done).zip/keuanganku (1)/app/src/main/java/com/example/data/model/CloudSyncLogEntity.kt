package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cloud_sync_logs")
data class CloudSyncLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String, // "BERHASIL", "GAGAL", "MENYINKRONKAN"
    val itemsSyncedCount: Int,
    val detailMessage: String
)
