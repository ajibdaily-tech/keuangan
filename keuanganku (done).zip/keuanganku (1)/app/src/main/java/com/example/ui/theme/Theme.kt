package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NaturalGreenLight,
    onPrimary = NaturalTextDark,
    primaryContainer = NaturalGreenPrimary,
    onPrimaryContainer = Color.White,
    background = NaturalDarkBackground,
    onBackground = Color.White,
    surface = NaturalDarkSurface,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF2A2D28),
    onSurfaceVariant = Color(0xFFC8CCC3),
    outline = Color(0xFF3F443D)
)

private val LightColorScheme = lightColorScheme(
    primary = NaturalGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = NaturalGreenLight,
    onPrimaryContainer = NaturalTextDark,
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF21005D),
    background = NaturalBackground,
    onBackground = NaturalTextDark,
    surface = NaturalSurface,
    onSurface = NaturalTextDark,
    surfaceVariant = NaturalSurfaceVariant,
    onSurfaceVariant = NaturalTextMedium,
    outline = NaturalBorder
)

@Composable
fun KeuanganKuTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    KeuanganKuTheme(darkTheme = darkTheme, content = content)
}
