package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.BudgetEntity
import com.example.data.model.CloudSyncLogEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.FinanceRepository
import com.example.data.sync.CloudSyncEngine
import com.example.data.sync.SyncState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class FilterType { ALL, INCOME, EXPENSE }
enum class PeriodType { ALL, THIS_MONTH, THIS_WEEK }

data class BudgetProgressItem(
    val category: String,
    val spentAmount: Double,
    val monthlyLimit: Double,
    val percentage: Float
)

data class FinanceUiState(
    val transactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val budgets: List<BudgetEntity> = emptyList(),
    val budgetProgressList: List<BudgetProgressItem> = emptyList(),
    val syncLogs: List<CloudSyncLogEntity> = emptyList(),
    val totalBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val unsyncedCount: Int = 0,
    val lastSyncTimestamp: Long? = null,
    val categoryExpenses: Map<String, Double> = emptyMap(),
    val searchQuery: String = "",
    val selectedFilter: FilterType = FilterType.ALL,
    val selectedPeriod: PeriodType = PeriodType.ALL,
    val isBalanceVisible: Boolean = true
)

private data class DataTriple(
    val transactions: List<TransactionEntity>,
    val budgets: List<BudgetEntity>,
    val syncLogs: List<CloudSyncLogEntity>
)

private data class FilterQuad(
    val searchQuery: String,
    val filter: FilterType,
    val period: PeriodType,
    val isVisible: Boolean
)

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FinanceRepository

    init {
        val database = AppDatabase.getDatabase(application)
        val engine = CloudSyncEngine(database.transactionDao(), database.cloudSyncLogDao())
        repository = FinanceRepository(
            transactionDao = database.transactionDao(),
            budgetDao = database.budgetDao(),
            cloudSyncLogDao = database.cloudSyncLogDao(),
            cloudSyncEngine = engine
        )
    }

    val syncState: StateFlow<SyncState> = repository.syncState
    val isAutoSyncEnabled: StateFlow<Boolean> = repository.isAutoSyncEnabled

    private val _searchQuery = MutableStateFlow("")
    private val _selectedFilter = MutableStateFlow(FilterType.ALL)
    private val _selectedPeriod = MutableStateFlow(PeriodType.ALL)
    private val _isBalanceVisible = MutableStateFlow(true)

    private val dbDataFlow = combine(
        repository.allTransactions,
        repository.allBudgets,
        repository.recentSyncLogs
    ) { txs, budgets, logs ->
        DataTriple(txs, budgets, logs)
    }

    private val filterDataFlow = combine(
        _searchQuery,
        _selectedFilter,
        _selectedPeriod,
        _isBalanceVisible
    ) { query, filter, period, isVis ->
        FilterQuad(query, filter, period, isVis)
    }

    val uiState: StateFlow<FinanceUiState> = combine(
        dbDataFlow,
        filterDataFlow
    ) { dataTriple, filterQuad ->
        val transactions = dataTriple.transactions
        val budgets = dataTriple.budgets
        val syncLogs = dataTriple.syncLogs

        val searchQuery = filterQuad.searchQuery
        val filter = filterQuad.filter
        val period = filterQuad.period
        val isVisible = filterQuad.isVisible

        val totalInc = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val totalExp = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val balance = totalInc - totalExp

        val unsynced = transactions.count { !it.isSynced }
        val lastSync = syncLogs.firstOrNull { it.status == "BERHASIL" }?.timestamp

        // Filter transactions based on search, type, and period
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()

        cal.timeInMillis = now
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val startOfMonth = cal.timeInMillis

        cal.timeInMillis = now
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val startOfWeek = cal.timeInMillis

        val filtered = transactions.filter { tx ->
            val matchesSearch = searchQuery.isBlank() ||
                    tx.title.contains(searchQuery, ignoreCase = true) ||
                    tx.category.contains(searchQuery, ignoreCase = true) ||
                    tx.note.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (filter) {
                FilterType.ALL -> true
                FilterType.INCOME -> tx.type == TransactionType.INCOME
                FilterType.EXPENSE -> tx.type == TransactionType.EXPENSE
            }

            val matchesPeriod = when (period) {
                PeriodType.ALL -> true
                PeriodType.THIS_MONTH -> tx.timestamp >= startOfMonth
                PeriodType.THIS_WEEK -> tx.timestamp >= startOfWeek
            }

            matchesSearch && matchesFilter && matchesPeriod
        }

        // Category breakdown for expenses
        val catMap = mutableMapOf<String, Double>()
        transactions.filter { it.type == TransactionType.EXPENSE }.forEach { tx ->
            catMap[tx.category] = (catMap[tx.category] ?: 0.0) + tx.amount
        }

        // Budget progress
        val progressList = budgets.map { budget ->
            val spent = catMap[budget.category] ?: 0.0
            val pct = if (budget.monthlyLimit > 0) (spent / budget.monthlyLimit).toFloat().coerceIn(0f, 1f) else 0f
            BudgetProgressItem(
                category = budget.category,
                spentAmount = spent,
                monthlyLimit = budget.monthlyLimit,
                percentage = pct
            )
        }

        FinanceUiState(
            transactions = transactions,
            filteredTransactions = filtered,
            budgets = budgets,
            budgetProgressList = progressList,
            syncLogs = syncLogs,
            totalBalance = balance,
            totalIncome = totalInc,
            totalExpense = totalExp,
            unsyncedCount = unsynced,
            lastSyncTimestamp = lastSync,
            categoryExpenses = catMap,
            searchQuery = searchQuery,
            selectedFilter = filter,
            selectedPeriod = period,
            isBalanceVisible = isVisible
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FinanceUiState()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterType(filter: FilterType) {
        _selectedFilter.value = filter
    }

    fun setPeriodType(period: PeriodType) {
        _selectedPeriod.value = period
    }

    fun toggleBalanceVisibility() {
        _isBalanceVisible.value = !_isBalanceVisible.value
    }

    fun saveTransaction(
        existingId: Long? = null,
        title: String,
        amount: Double,
        type: TransactionType,
        category: String,
        note: String
    ) {
        viewModelScope.launch {
            if (existingId == null || existingId == 0L) {
                val tx = TransactionEntity(
                    title = title,
                    amount = amount,
                    type = type,
                    category = category,
                    note = note,
                    timestamp = System.currentTimeMillis()
                )
                repository.addTransaction(tx)
            } else {
                val tx = TransactionEntity(
                    id = existingId,
                    title = title,
                    amount = amount,
                    type = type,
                    category = category,
                    note = note,
                    timestamp = System.currentTimeMillis(),
                    isSynced = false
                )
                repository.updateTransaction(tx)
            }
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun saveBudget(category: String, limit: Double) {
        viewModelScope.launch {
            repository.setBudget(BudgetEntity(category = category, monthlyLimit = limit))
        }
    }

    fun deleteBudget(category: String) {
        viewModelScope.launch {
            repository.deleteBudgetByCategory(category)
        }
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            repository.triggerCloudSync()
        }
    }

    fun setAutoSyncEnabled(enabled: Boolean) {
        repository.setAutoSyncEnabled(enabled)
    }

    fun clearSyncLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun exportTransactionsToJson(): String {
        return repository.cloudSyncEngine.exportTransactionsToJson(uiState.value.transactions)
    }

    fun importTransactionsFromJson(jsonString: String, onComplete: (Int) -> Unit) {
        viewModelScope.launch {
            val count = repository.importTransactionsFromJson(jsonString)
            onComplete(count)
        }
    }
}

class FinanceViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FinanceViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FinanceViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
