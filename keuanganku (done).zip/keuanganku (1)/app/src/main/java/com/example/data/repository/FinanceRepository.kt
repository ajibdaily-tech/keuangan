package com.example.data.repository

import com.example.data.dao.BudgetDao
import com.example.data.dao.CloudSyncLogDao
import com.example.data.dao.TransactionDao
import com.example.data.model.BudgetEntity
import com.example.data.model.CloudSyncLogEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.sync.CloudSyncEngine
import com.example.data.sync.SyncResult
import com.example.data.sync.SyncState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val budgetDao: BudgetDao,
    private val cloudSyncLogDao: CloudSyncLogDao,
    val cloudSyncEngine: CloudSyncEngine
) {

    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allBudgets: Flow<List<BudgetEntity>> = budgetDao.getAllBudgets()
    val recentSyncLogs: Flow<List<CloudSyncLogEntity>> = cloudSyncLogDao.getRecentLogs()
    val syncState: StateFlow<SyncState> = cloudSyncEngine.syncState
    val isAutoSyncEnabled: StateFlow<Boolean> = cloudSyncEngine.isAutoSyncEnabled

    suspend fun addTransaction(transaction: TransactionEntity) {
        val newItem = transaction.copy(isSynced = false)
        transactionDao.insertTransaction(newItem)

        if (isAutoSyncEnabled.value) {
            cloudSyncEngine.performSync()
        }
    }

    suspend fun updateTransaction(transaction: TransactionEntity) {
        val updatedItem = transaction.copy(isSynced = false)
        transactionDao.updateTransaction(updatedItem)

        if (isAutoSyncEnabled.value) {
            cloudSyncEngine.performSync()
        }
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        transactionDao.deleteTransaction(transaction)

        if (isAutoSyncEnabled.value) {
            cloudSyncEngine.performSync()
        }
    }

    suspend fun setBudget(budget: BudgetEntity) {
        budgetDao.setBudget(budget)
    }

    suspend fun deleteBudgetByCategory(category: String) {
        budgetDao.deleteBudgetByCategory(category)
    }

    suspend fun triggerCloudSync(): SyncResult {
        return cloudSyncEngine.performSync()
    }

    fun setAutoSyncEnabled(enabled: Boolean) {
        cloudSyncEngine.setAutoSyncEnabled(enabled)
    }

    suspend fun clearLogs() {
        cloudSyncLogDao.clearLogs()
    }

    suspend fun importTransactionsFromJson(jsonString: String): Int {
        return try {
            val root = JSONObject(jsonString)
            val array = root.getJSONArray("transactions")
            val importedList = mutableListOf<TransactionEntity>()
            val now = System.currentTimeMillis()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val title = obj.getString("title")
                val amount = obj.getDouble("amount")
                val typeStr = obj.getString("type")
                val type = if (typeStr == "INCOME") TransactionType.INCOME else TransactionType.EXPENSE
                val category = obj.getString("category")
                val note = obj.optString("note", "")
                val timestamp = obj.optLong("timestamp", now)

                importedList.add(
                    TransactionEntity(
                        title = title,
                        amount = amount,
                        type = type,
                        category = category,
                        note = note,
                        timestamp = timestamp,
                        isSynced = true,
                        lastSyncedAt = now
                    )
                )
            }

            if (importedList.isNotEmpty()) {
                transactionDao.insertTransactions(importedList)
                cloudSyncLogDao.insertLog(
                    CloudSyncLogEntity(
                        timestamp = now,
                        status = "BERHASIL",
                        itemsSyncedCount = importedList.size,
                        detailMessage = "Impor data cloud JSON berhasil. ${importedList.size} transaksi ditambahkan."
                    )
                )
            }
            importedList.size
        } catch (e: Exception) {
            0
        }
    }
}
