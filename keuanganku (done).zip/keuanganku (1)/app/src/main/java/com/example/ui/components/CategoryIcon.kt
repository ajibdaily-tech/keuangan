package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class CategoryMeta(
    val icon: ImageVector,
    val color: Color
)

object CategoryHelper {
    val categories = listOf(
        "Makanan & Minuman",
        "Belanja Dapur",
        "Transportasi",
        "Tagihan & Utilitas",
        "Gaji & Pendapatan",
        "Freelance & Usaha",
        "Hiburan",
        "Investasi",
        "Lainnya"
    )

    fun getMeta(category: String): CategoryMeta {
        return when {
            category.contains("Makanan", ignoreCase = true) || category.contains("Makan", ignoreCase = true) ->
                CategoryMeta(Icons.Default.Fastfood, Color(0xFFF59E0B))
            category.contains("Belanja", ignoreCase = true) || category.contains("Dapur", ignoreCase = true) ->
                CategoryMeta(Icons.Default.ShoppingBag, Color(0xFF8B5CF6))
            category.contains("Transport", ignoreCase = true) || category.contains("Bensin", ignoreCase = true) ->
                CategoryMeta(Icons.Default.DirectionsCar, Color(0xFF3B82F6))
            category.contains("Tagihan", ignoreCase = true) || category.contains("Listrik", ignoreCase = true) ->
                CategoryMeta(Icons.Default.Receipt, Color(0xFFEF4444))
            category.contains("Gaji", ignoreCase = true) || category.contains("Pendapatan", ignoreCase = true) ->
                CategoryMeta(Icons.Default.AccountBalanceWallet, Color(0xFF10B981))
            category.contains("Freelance", ignoreCase = true) || category.contains("Usaha", ignoreCase = true) ->
                CategoryMeta(Icons.Default.Work, Color(0xFF06B6D4))
            category.contains("Hiburan", ignoreCase = true) ->
                CategoryMeta(Icons.Default.Movie, Color(0xFFEC4899))
            category.contains("Investasi", ignoreCase = true) ->
                CategoryMeta(Icons.Default.AttachMoney, Color(0xFF10B981))
            else ->
                CategoryMeta(Icons.Default.Category, Color(0xFF6B7280))
        }
    }
}

@Composable
fun CategoryIconBadge(
    category: String,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    val meta = CategoryHelper.getMeta(category)
    Box(
        modifier = modifier
            .size(size)
            .background(color = meta.color.copy(alpha = 0.15f), shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = meta.icon,
            contentDescription = category,
            tint = meta.color,
            modifier = Modifier.size(size * 0.55f)
        )
    }
}
