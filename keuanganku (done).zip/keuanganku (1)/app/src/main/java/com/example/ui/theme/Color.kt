package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NaturalGreenPrimary = Color(0xFF43664E)
val NaturalGreenDark = Color(0xFF2E4D37)
val NaturalGreenLight = Color(0xFFDDE5D7)
val NaturalBackground = Color(0xFFFAF9F6)
val NaturalSurface = Color(0xFFFFFFFF)
val NaturalSurfaceVariant = Color(0xFFF0F5ED)
val NaturalTextDark = Color(0xFF1A1C19)
val NaturalTextMedium = Color(0xFF444941)
val NaturalBorder = Color(0xFFE1E3DE)

val NaturalIncomeGreen = Color(0xFF43664E)
val NaturalExpenseRed = Color(0xFFBA1A1A)

val NaturalDarkBackground = Color(0xFF121411)
val NaturalDarkSurface = Color(0xFF1A1C19)
