package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CloudSyncLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CloudSyncLogDao {
    @Query("SELECT * FROM cloud_sync_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentLogs(): Flow<List<CloudSyncLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CloudSyncLogEntity)

    @Query("DELETE FROM cloud_sync_logs")
    suspend fun clearLogs()
}
