package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TransactionEntity
import com.example.ui.FinanceViewModel
import com.example.ui.FinanceViewModelFactory
import com.example.ui.dialogs.AddEditTransactionDialog
import com.example.ui.dialogs.CloudBackupDialog
import com.example.ui.dialogs.SetBudgetDialog
import com.example.ui.screens.BudgetsScreen
import com.example.ui.screens.CloudSyncScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.theme.KeuanganKuTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: FinanceViewModel by viewModels {
        FinanceViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KeuanganKuTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: FinanceViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val syncState by viewModel.syncState.collectAsState()
    val isAutoSyncEnabled by viewModel.isAutoSyncEnabled.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Home, 1: Transaksi, 2: Anggaran, 3: Sync

    var showAddEditDialog by remember { mutableStateOf(false) }
    var transactionToEdit by remember { mutableStateOf<TransactionEntity?>(null) }

    var showSetBudgetDialog by remember { mutableStateOf(false) }
    var budgetCategoryToEdit by remember { mutableStateOf<String?>(null) }
    var budgetLimitToEdit by remember { mutableStateOf<Double?>(null) }

    var showCloudBackupDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Beranda") },
                    label = { Text("Beranda", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF43664E),
                        selectedTextColor = Color(0xFF43664E),
                        indicatorColor = Color(0xFFDDE5D7)
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = "Transaksi") },
                    label = { Text("Transaksi", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF43664E),
                        selectedTextColor = Color(0xFF43664E),
                        indicatorColor = Color(0xFFDDE5D7)
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(imageVector = Icons.Default.PieChart, contentDescription = "Anggaran") },
                    label = { Text("Anggaran", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF43664E),
                        selectedTextColor = Color(0xFF43664E),
                        indicatorColor = Color(0xFFDDE5D7)
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(imageVector = Icons.Default.CloudSync, contentDescription = "Cloud") },
                    label = { Text("Cloud Sync", fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF43664E),
                        selectedTextColor = Color(0xFF43664E),
                        indicatorColor = Color(0xFFDDE5D7)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = selectedTab, label = "TabCrossfade") { tab ->
                when (tab) {
                    0 -> HomeScreen(
                        uiState = uiState,
                        syncState = syncState,
                        onToggleBalanceVisibility = { viewModel.toggleBalanceVisibility() },
                        onTriggerSync = { viewModel.triggerCloudSync() },
                        onAddTransactionClick = {
                            transactionToEdit = null
                            showAddEditDialog = true
                        },
                        onOpenBudgetClick = { selectedTab = 2 },
                        onViewAllTransactionsClick = { selectedTab = 1 },
                        onEditTransaction = { tx ->
                            transactionToEdit = tx
                            showAddEditDialog = true
                        },
                        onDeleteTransaction = { tx ->
                            viewModel.deleteTransaction(tx)
                            scope.launch { snackbarHostState.showSnackbar("Transaksi dihapus") }
                        }
                    )

                    1 -> TransactionsScreen(
                        uiState = uiState,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        onFilterChange = { viewModel.setFilterType(it) },
                        onPeriodChange = { viewModel.setPeriodType(it) },
                        onAddTransactionClick = {
                            transactionToEdit = null
                            showAddEditDialog = true
                        },
                        onEditTransaction = { tx ->
                            transactionToEdit = tx
                            showAddEditDialog = true
                        },
                        onDeleteTransaction = { tx ->
                            viewModel.deleteTransaction(tx)
                            scope.launch { snackbarHostState.showSnackbar("Transaksi dihapus") }
                        }
                    )

                    2 -> BudgetsScreen(
                        uiState = uiState,
                        onSetBudgetClick = {
                            budgetCategoryToEdit = null
                            budgetLimitToEdit = null
                            showSetBudgetDialog = true
                        },
                        onEditBudget = { cat, lim ->
                            budgetCategoryToEdit = cat
                            budgetLimitToEdit = lim
                            showSetBudgetDialog = true
                        },
                        onDeleteBudget = { cat ->
                            viewModel.deleteBudget(cat)
                            scope.launch { snackbarHostState.showSnackbar("Target anggaran $cat dihapus") }
                        }
                    )

                    3 -> CloudSyncScreen(
                        uiState = uiState,
                        syncState = syncState,
                        isAutoSyncEnabled = isAutoSyncEnabled,
                        onToggleAutoSync = { viewModel.setAutoSyncEnabled(it) },
                        onTriggerSync = { viewModel.triggerCloudSync() },
                        onOpenBackupDialog = { showCloudBackupDialog = true },
                        onClearLogs = { viewModel.clearSyncLogs() }
                    )
                }
            }
        }
    }

    // Dialogs
    if (showAddEditDialog) {
        AddEditTransactionDialog(
            transactionToEdit = transactionToEdit,
            onDismiss = { showAddEditDialog = false },
            onSave = { title, amount, type, category, note ->
                viewModel.saveTransaction(
                    existingId = transactionToEdit?.id,
                    title = title,
                    amount = amount,
                    type = type,
                    category = category,
                    note = note
                )
                scope.launch { snackbarHostState.showSnackbar("Transaksi berhasil disimpan") }
            }
        )
    }

    if (showSetBudgetDialog) {
        SetBudgetDialog(
            categoryToEdit = budgetCategoryToEdit,
            currentLimit = budgetLimitToEdit,
            onDismiss = { showSetBudgetDialog = false },
            onSave = { category, limit ->
                viewModel.saveBudget(category, limit)
                scope.launch { snackbarHostState.showSnackbar("Target anggaran $category disimpan") }
            }
        )
    }

    if (showCloudBackupDialog) {
        CloudBackupDialog(
            exportJsonString = viewModel.exportTransactionsToJson(),
            onDismiss = { showCloudBackupDialog = false },
            onImportJson = { jsonText, onResult ->
                viewModel.importTransactionsFromJson(jsonText) { importedCount ->
                    onResult(importedCount)
                    if (importedCount > 0) {
                        scope.launch { snackbarHostState.showSnackbar("Berhasil mengimpor $importedCount transaksi") }
                    }
                }
            }
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}
