package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.BudgetDao
import com.example.data.dao.CloudSyncLogDao
import com.example.data.dao.TransactionDao
import com.example.data.model.BudgetEntity
import com.example.data.model.CloudSyncLogEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromTransactionType(value: TransactionType): String = value.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType = TransactionType.valueOf(value)
}

@Database(
    entities = [
        TransactionEntity::class,
        BudgetEntity::class,
        CloudSyncLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao
    abstract fun cloudSyncLogDao(): CloudSyncLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "keuangan_pribadi_db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: AppDatabase) {
                val transactionDao = database.transactionDao()
                val budgetDao = database.budgetDao()
                val logDao = database.cloudSyncLogDao()

                val now = System.currentTimeMillis()
                val day = 24 * 60 * 60 * 1000L

                // Initial sample transactions in IDR
                val sampleTransactions = listOf(
                    TransactionEntity(
                        title = "Gaji Bulanan",
                        amount = 12500000.0,
                        type = TransactionType.INCOME,
                        category = "Gaji & Pendapatan",
                        note = "Transfer Gaji PT Indonesia Jaya",
                        timestamp = now - (1 * day),
                        isSynced = true,
                        lastSyncedAt = now - (1 * day)
                    ),
                    TransactionEntity(
                        title = "Belanja Bulanan Supermarket",
                        amount = 1450000.0,
                        type = TransactionType.EXPENSE,
                        category = "Belanja Dapur",
                        note = "Minyak, beras, daging & bahan makanan",
                        timestamp = now - (2 * day),
                        isSynced = true,
                        lastSyncedAt = now - (2 * day)
                    ),
                    TransactionEntity(
                        title = "Tagihan Listrik & Air",
                        amount = 680000.0,
                        type = TransactionType.EXPENSE,
                        category = "Tagihan & Utilitas",
                        note = "Listrik PLN Token + PDAM",
                        timestamp = now - (3 * day),
                        isSynced = true,
                        lastSyncedAt = now - (3 * day)
                    ),
                    TransactionEntity(
                        title = "Makan Siang Resto Bakmi",
                        amount = 75000.0,
                        type = TransactionType.EXPENSE,
                        category = "Makanan & Minuman",
                        note = "Makan siang kantor",
                        timestamp = now - (4 * day),
                        isSynced = true,
                        lastSyncedAt = now - (4 * day)
                    ),
                    TransactionEntity(
                        title = "Proyek Freelance UI Design",
                        amount = 3200000.0,
                        type = TransactionType.INCOME,
                        category = "Freelance & Usaha",
                        note = "DP Desain Aplikasi Mobile",
                        timestamp = now - (5 * day),
                        isSynced = true,
                        lastSyncedAt = now - (5 * day)
                    ),
                    TransactionEntity(
                        title = "Bensin Pertamax",
                        amount = 150000.0,
                        type = TransactionType.EXPENSE,
                        category = "Transportasi",
                        note = "Isi bensin mobil",
                        timestamp = now - (6 * day),
                        isSynced = false,
                        lastSyncedAt = null
                    ),
                    TransactionEntity(
                        title = "Langganan Netflix & Spotify",
                        amount = 230000.0,
                        type = TransactionType.EXPENSE,
                        category = "Hiburan",
                        note = "Paket bulanan hiburan keluarga",
                        timestamp = now - (7 * day),
                        isSynced = true,
                        lastSyncedAt = now - (7 * day)
                    )
                )

                transactionDao.insertTransactions(sampleTransactions)

                // Initial budget targets
                val sampleBudgets = listOf(
                    BudgetEntity(category = "Makanan & Minuman", monthlyLimit = 2500000.0),
                    BudgetEntity(category = "Belanja Dapur", monthlyLimit = 2000000.0),
                    BudgetEntity(category = "Transportasi", monthlyLimit = 1000000.0),
                    BudgetEntity(category = "Tagihan & Utilitas", monthlyLimit = 1500000.0),
                    BudgetEntity(category = "Hiburan", monthlyLimit = 800000.0)
                )

                budgetDao.insertBudgets(sampleBudgets)

                // Initial Cloud Sync Log
                logDao.insertLog(
                    CloudSyncLogEntity(
                        timestamp = now - (1 * day),
                        status = "BERHASIL",
                        itemsSyncedCount = 6,
                        detailMessage = "Sinkronisasi otomatis cloud server selesai."
                    )
                )
            }
        }
    }
}
